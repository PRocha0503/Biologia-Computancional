library(seqinr)
library(ggplot2)
library(Biostrings)
library(ape)
library(ggtree)
library(DECIPHER)
library(viridis)
library(ggplot2)
## Agregar Sequencias
sequencias = read.fasta("todos.fasta")
nombres =c("229E_n","229E_v","NL63_n","NL63_v","OC43_n","OC43_v","HKU1_n","HKU1_v","MERS_nAS","MERS_nUK","MERS_v","SARS_vHK","SARS_vUS","SARS_nUS","S2_nUS04","S2_nUS01","S2_nUK12","S2_vUK","S2_ref","S2_nBR","S2_nIN","S2_nMX")
nombres_graf =c("2n","2v","Nn","Nv","On","Ov","Hn","Hv","MnA","MnU","Mv","SvH","SvU","SnU","S2nUS1","S2nUS2","S2nUK","S2vUK","S2r","S2B","S2I","S2M")

##Cambiamos nombres para que sean mas faciles de entender
for(i in 1:length(sequencias))
  attr(sequencias[[i]],"name") = nombres[i]

## Calculamos el tamaño de cada una:
tamaños = c();
for (elemento in sequencias){
  tam = length(elemento);
  tamaños = c(tamaños,tam);
}

imprimirTamaños = function(size,seq){
  for(s in seq){
    nom = attr(s,"name");
    print(nom)
    print(length(s))
  }
}
imprimirTamaños(tamaños,sequencias)
## Calculamos porcentaje de cada nucleotido
lista_porcentajes = c()
porcentajePorBase = function(listadna,tamaño,lisa_por){
  porcentajes = c()
  contadorA = 0;
  contadorG = 0;
  contadorT = 0;
  contadorC = 0;
  contadorN = 0;
  for(elemento in listadna){
    if(elemento == "a"){
      contadorA = contadorA + 1;
    }
    else if(elemento == "g"){
      contadorG = contadorG + 1;
    }
    else if(elemento == "t"){
      contadorT = contadorT + 1;
    }
    else if(elemento == "c"){
      contadorC = contadorC + 1;
    }
    else{
      contadorN = contadorN + 1;
    }
  }
  porcentajes= c(porcentajes, ((contadorA/(tamaño-contadorN))*100))
  porcentajes= c(porcentajes, ((contadorG/(tamaño-contadorN))*100))
  porcentajes= c(porcentajes, ((contadorT/(tamaño-contadorN))*100))
  porcentajes= c(porcentajes, ((contadorC/(tamaño-contadorN))*100))
  return(lista_por = c(lisa_por,porcentajes))
}

imprimirPorcentajes = function(lista_por,seq){
  contador = 0;
  for(s in seq){
    nom = attr(s,"name");
    tamaño = length(s)
    lista_por = porcentajePorBase(s,tamaño,lista_por)
    attr(s,"A") = (lista_por[contador + 1])
    attr(s,"G") = (lista_por[contador + 2])
    attr(s,"T") = (lista_por[contador + 3])
    attr(s,"C") = (lista_por[contador + 4])
    contador = contador + 4;
  }
  return(lista_por)
}
lista_porcentajes = imprimirPorcentajes(lista_porcentajes,sequencias)

## Asignar porcentajes como atributo para aceso facil
contador = 0
for(i in 1:length(sequencias)){
  attr(sequencias[[i]],"A") = (lista_porcentajes[contador + 1])
  attr(sequencias[[i]],"G") = (lista_porcentajes[contador + 2])
  attr(sequencias[[i]],"T") = (lista_porcentajes[contador + 3])
  attr(sequencias[[i]],"C") = (lista_porcentajes[contador + 4])
  contador = contador + 4;
}
contador = 0
as = c()
for(i in 1:length(sequencias)){
  as = c(as,lista_porcentajes[1+contador])
  contador = contador + 4
}
gs = c()
contador = 0
for(i in 1:length(sequencias)){
  gs = c(gs,lista_porcentajes[2+contador])
  contador = contador + 4
}
ts = c()
contador = 0
for(i in 1:length(sequencias)){
  ts = c(ts,lista_porcentajes[3+contador])
  contador = contador + 4
}
cs = c()
contador = 0
for(i in 1:length(sequencias)){
  cs = c(cs,lista_porcentajes[4+contador])
  contador = contador + 4
}

## Grafica de todos 
letras <- c(rep("A" , 22) , rep("G" , 22) , rep("T" , 22) , rep("C" , 22) )
nombres_rep = rep(nombres_graf,4)
todos = c()
todos = c(todos,as)
todos = c(todos,cs)
todos = c(todos,ts)
todos = c(todos,gs)
data = data.frame(nombres_rep,letras,todos)

ggplot(data, aes(fill=letras, y=todos, x=nombres_rep)) + geom_bar(position="dodge", stat="identity")+labs(y="% de nucleotidos", x = "Paises")+
  theme(text = element_text(size=20),axis.text.x = element_text(angle=90, hjust=1)) 


# ##GRaficar por enfermedad
# mers = c()
# sars = c()
# sars2 = c()
# 
# mcant = 0
# msuma_a = 0
# msuma_g = 0
# msuma_t = 0
# msuma_c = 0
# 
# scant = 0
# ssuma_a = 0
# ssuma_g = 0
# ssuma_t = 0
# ssuma_c = 0
# 
# s2cant = 0
# s2suma_a = 0
# s2suma_g = 0
# s2suma_t = 0
# s2suma_c = 0
# 
# for(i in 1:length(sequencias)){
#   if(grepl("MERS",attr(sequencias[[i]],"Annot"), fixed = TRUE)){
#     mcant = mcant + 1
#     msuma_a = msuma_a + attr(sequencias[[i]],"A") 
#     msuma_g = msuma_g + attr(sequencias[[i]],"G")
#     msuma_t = msuma_t + attr(sequencias[[i]],"T")
#     msuma_c = msuma_c + attr(sequencias[[i]],"C")
#   }
#   if(grepl("SARS",attr(sequencias[[i]],"Annot"), fixed = TRUE)){
#     scant = scant + 1
#     ssuma_a = ssuma_a + attr(sequencias[[i]],"A") 
#     ssuma_g = ssuma_g + attr(sequencias[[i]],"G")
#     ssuma_t = ssuma_t + attr(sequencias[[i]],"T")
#     ssuma_c = ssuma_a + attr(sequencias[[i]],"C")
#   }
#   if(grepl("S2",attr(sequencias[[i]],"Annot"), fixed = TRUE)){
#     s2cant = s2cant + 1
#     s2suma_a = s2suma_a + attr(sequencias[[i]],"A") 
#     s2suma_g = s2suma_g + attr(sequencias[[i]],"G")
#     s2suma_t = s2suma_t + attr(sequencias[[i]],"T")
#     s2suma_c = s2suma_c + attr(sequencias[[i]],"C")
#   }
# }
# mprom_a = msuma_a/mcant
# mprom_g = msuma_g/mcant
# mprom_t = msuma_t/mcant
# mprom_c = msuma_c/mcant
# mers = c(mprom_a,mprom_g,mprom_t,mprom_c)
# 
# sprom_a = ssuma_a/scant
# sprom_g = ssuma_g/scant
# sprom_t = ssuma_t/scant
# sprom_c = ssuma_c/scant
# sars = c(sprom_a,sprom_g,sprom_t,sprom_c)
# 
# s2prom_a = s2suma_a/s2cant
# s2prom_g = s2suma_g/s2cant
# s2prom_t = s2suma_t/s2cant
# s2prom_c = s2suma_c/s2cant
# sars2 = c(s2prom_a,s2prom_g,s2prom_t,s2prom_c)
# 
# letras <- c(rep("A" , 3) , rep("G" ,3) , rep("T" , 3) , rep("C" , 3) )
# enfermedades = rep(c("MERS","SARS","SARS2"),4)
# todos = c()
# todos = c(todos,mers)
# todos = c(todos,sars)
# todos = c(todos,sars2)
# data = data.frame(enfermedades,letras,todos)
# 
# ggplot(data, aes(fill=enfermedades, y=todos, x=letras)) + geom_bar(position="dodge", stat="identity")+labs(y="% de nucleotidos", x = "Nucleotidos")

## Para hacer el arbol
#write.dna(sequencias,  file ="virus_seqs.fasta", format = "fasta", append =FALSE, nbcol = 6, colsep = "", colw = 10)
virus_seq_not_align = readDNAStringSet("todos.fasta", format = "fasta")
for(i in 1:length(virus_seq_not_align)){
  names(virus_seq_not_align)[i] = nombres[i] 
}
virus_seq_not_align = OrientNucleotides(virus_seq_not_align)
virus_seq_align = AlignSeqs(virus_seq_not_align)
writeXStringSet(virus_seq_align, file="virus_seq_align.fasta")
virus_aligned = read.alignment("virus_seq_align.fasta", format = "fasta")
matriz_distancia = dist.alignment(virus_aligned, matrix = "similarity")
virus_tree = nj(matriz_distancia)
virus_tree = ladderize(virus_tree)
plot(virus_tree, cex = 0.6)
title("Arbol de los coronavirus")

